let nike = [
  {
    id: 1,
    title: "에어 줌 인피니티 투어 넥스트",
    imgUrl: "img/nike/nike1.jpg",
    content: "남성 골프화(와이드)",
    price: 259001,
  },
  {
    id: 2,
    title: "르브론 19 ",
    imgUrl: "img/nike/nike2.jpg",
    content: "남녀공용 농구화",
    price: 239002,
  },
  {
    id: 3,
    title: "에어맥스 97 OG",
    imgUrl: "img/nike/nike3.jpg",
    content: "남성신발",
    price: 219000,
  },
];

export default nike;
