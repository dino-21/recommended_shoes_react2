import React from "react";

const Title = () => {
  let csst1 = {
    marginTop: "70px",
    textAlign: "center",
  };
  return (
    <>
      <h3 style={csst1}>MD's Pick </h3>
      <p style={{ textAlign: "center" }}>
        {" "}
        시선을 사로잡는 스타일링, 제품들을 만나보세요.
      </p>
    </>
  );
};

export default Title;
