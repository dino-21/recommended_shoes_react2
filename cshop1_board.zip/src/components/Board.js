import React, { useState } from 'react';
import { Button, Table, Form, Modal } from 'react-bootstrap';

const Board = () => {
    const [board, setBoard] = useState([
        { no: "1", title: '새로운 스니커즈 출시', content: '이번 시즌 새로운 스니커즈 트렌드와 특징을 알아봅니다.', view: '1' },
        { no: "2", title: '하이킹 부츠 추천', content: '산행에 적합한 하이킹 부츠와 착화감을 리뷰합니다.', view: '2' },
        { no: "3", title: '캐주얼 샌들 스타일링', content: '여름철 캐주얼 샌들을 멋지게 연출하는 방법을 소개합니다.', view: '3' },
        { no: "4", title: '러닝화를 선택할 때 고려할 점', content: '러닝화의 착용감과 기능을 비교해 보았습니다.', view: '4' }
    ]);
    const [listOk, setListOk] = useState(true);
    const [readOk, setReadOk] = useState(false);
    const [writeOk, setWriteOk] = useState(false);
    const [editOk, setEditOk] = useState(false);
    const [boardInfo, setBoardInfo] = useState({});
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [editTitle, setEditTitle] = useState('');
    const [editContent, setEditContent] = useState('');
    const [editNo, setEditNo] = useState(null);

    // 게시판 목록 보기
    const boardList = () => {
        setReadOk(false);
        setWriteOk(false);
        setEditOk(false);
        setListOk(true);
    };

    // 글 읽기
    const boardRead = (item) => {
        setListOk(false);
        setReadOk(true);
        setBoardInfo(item);
        const updatedBoard = board.map(b =>
            b.no === item.no ? { ...b, view: parseInt(b.view) + 1 } : b
        );
        setBoard(updatedBoard);
    };

    // 글 쓰기 화면
    const boardWrite = () => {
        setListOk(false);
        setWriteOk(true);
    };

    // 글 저장
    const boardSave = () => {
        const newBoard = {
            no: (board.length + 1).toString(),
            title: title,
            content: content,
            view: '0'
        };
        setBoard([...board, newBoard]);
        setTitle('');
        setContent('');
        boardList();
    };

    // 글 삭제
    const boardDelete = (no) => {
        setBoard(board.filter(item => item.no !== no));
    };

    // 글 수정 화면
    const boardEdit = (item) => {
        setEditOk(true);
        setListOk(false);
        setEditNo(item.no);
        setEditTitle(item.title);
        setEditContent(item.content);
    };

    // 글 수정 저장
    const updateBoard = () => {
        const updatedBoard = board.map(b =>
            b.no === editNo ? { ...b, title: editTitle, content: editContent } : b
        );
        setBoard(updatedBoard);
        boardList();
    };

    return (
        <div  class="container" style={{ marginTop: "80px" }}>
            


          <h3>게시판(상품문의)</h3>
            {/* 게시판 목록 */}
            {listOk && (
                <div>
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th>글번호</th>
                                <th>글제목</th>
                                <th>조회수</th>
                                <th>바로가기</th>
                            </tr>
                        </thead>
                        <tbody>
                            {/* {board.map(item => ( //ASC 순서 */}
                             {board.slice().reverse().map(item => (
                                <tr key={item.no}>
                                    <td>{item.no}</td>
                                    <td style={{ cursor: 'pointer' }} onClick={() => boardRead(item)}>
                                        {item.title}
                                    </td>
                                    <td>{item.view}</td>
                                    <td>
                                       
                                        <Button variant="outline-success" onClick={() => boardEdit(item)} style={{marginRight:"10px"}}>수정</Button> 
                                        <Button variant="outline-danger" onClick={() => boardDelete(item.no)}>삭제</Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                    <Button variant="primary" onClick={boardWrite} style={{ float: 'right' }}>
                        글쓰기
                    </Button>
                </div>
            )}

            {/* 글 읽기 */}
            {readOk && (
                <div>
                    <h3>{boardInfo.title}</h3>
                    <p>{boardInfo.content}</p>
                    <Button variant="secondary" onClick={boardList}>
                        목록으로
                    </Button>
                </div>
            )}

            {/* 글쓰기 화면 */}
            {writeOk && (
                <div>
                    <h3>글쓰기</h3>
                    <Form.Group controlId="formTitle">
                        <Form.Control
                            type="text"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            placeholder="제목을 입력하세요"
                        />
                    </Form.Group>
                    <Form.Group controlId="formContent">
                        <Form.Control
                            as="textarea"
                            rows={3}
                            value={content}
                            onChange={(e) => setContent(e.target.value)}
                            placeholder="내용을 입력하세요"
                        />
                    </Form.Group>
                    <Button variant="primary" onClick={boardSave}>저장</Button>
                    <Button variant="secondary" onClick={boardList}>목록으로</Button>
                </div>
            )}

            {/* 글 수정 화면 */}
            {editOk && (
                <div>
                    <h5>글 수정</h5>
                    <Form.Group controlId="formEditTitle">
                        <Form.Control
                            type="text"
                            value={editTitle}
                            onChange={(e) => setEditTitle(e.target.value)}
                            placeholder="수정된 제목"
                        />
                    </Form.Group>
                    <p/>
                    <Form.Group controlId="formEditContent">
                        <Form.Control
                            as="textarea"
                            rows={3}
                            value={editContent}
                            onChange={(e) => setEditContent(e.target.value)}
                            placeholder="수정된 내용"
                        />
                    </Form.Group>
                    <p/>
                    <div style={{textAlign:'right'}}>
                        <Button variant="outline-success" onClick={updateBoard} style={{marginRight:"10px"}}>수정 </Button>
                        <Button variant="outline-info" onClick={boardList}>목록으로</Button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Board;
